import 'package:flutter/material.dart';

const Color primary = Colors.black;
const  red = Colors.red;
const Color white = Colors.white;
const Color black = Colors.black;
const Color grey = Colors.grey;
const Color green = Colors.green;
Color active = Colors.orange[200];
Color disabled = Colors.grey[200];



